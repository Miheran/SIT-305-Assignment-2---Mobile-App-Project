package com.example.doggycaregame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DogGameMain : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dog_game_main)
    }
}
